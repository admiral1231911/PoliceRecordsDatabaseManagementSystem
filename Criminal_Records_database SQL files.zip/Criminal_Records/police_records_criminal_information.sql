-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: police_records
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `criminal_information`
--

DROP TABLE IF EXISTS `criminal_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `criminal_information` (
  `crimID` int(11) NOT NULL AUTO_INCREMENT,
  `familyname` varchar(45) NOT NULL,
  `firstname` varchar(45) NOT NULL,
  `middlename` varchar(45) NOT NULL,
  `nickname` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `civilstatus` varchar(45) NOT NULL,
  `birthdate` date NOT NULL,
  `city` varchar(45) DEFAULT NULL,
  `province` varchar(45) NOT NULL,
  `homeaddress` varchar(45) NOT NULL,
  `workaddress` varchar(45) DEFAULT NULL,
  `emailaddress` varchar(45) DEFAULT NULL,
  `phonenum` varchar(45) DEFAULT NULL,
  `mobilenum` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`crimID`)
) ENGINE=InnoDB AUTO_INCREMENT=1011 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `criminal_information`
--

LOCK TABLES `criminal_information` WRITE;
/*!40000 ALTER TABLE `criminal_information` DISABLE KEYS */;
INSERT INTO `criminal_information` VALUES (1001,'Ibacarra','Rogelio','Rosel','Nigerian Prince','Male','Divorced','2000-02-26','Cagayan de Oro','Misamis Oriental','Capistrano','Xavier University','princeofbelair@yahoo.com','000 666 999','000 666 999'),(1009,'asdf','sdfa','asdf','asfd','Male','Single','2019-10-18','sdfasd','asdf','asdf','asdf','asdf','asdf','asdf'),(1010,'Dela Cruz','Francis James','Idunno','TheGayMan','Male','Single','1997-12-18','Tagoloan','Misamis Oriental','gayland','LGBTQ+ Headquarters,','GayJames@yahoo.com','111 111 111','111 111 111');
/*!40000 ALTER TABLE `criminal_information` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-15 11:14:06
