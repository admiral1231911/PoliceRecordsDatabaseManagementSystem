package forJavaDocfinal;

/**
 * @author Rogelio Jr Ibacarra and Benz Walter Jacques Tan
 * @since Created October 5, 2019
 * @version  1.2
 * @title Police Records Database Management System
 */
/**
 * Represents Main
 */
public class Main {

	/**
	 * Runs the Loging class
	 * @param args
	 */
	public static void main(String args[]) {

		Login login = new Login();
		
		login.runLogin();
	}
}
